# Every journey needs a start, every program needs a main

{{#literatego ./testdata/emptymain.go}}

With that out of the way, we can get on to scaffolding our API!
