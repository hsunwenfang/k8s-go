# Kubebuilder Logos

The official location for the logos is in a [public GCS
bucket][kb-logos-gcs] (or if you like GCS XML listings,
[here][kb-logos-gcs-direct]).

These logos are copies used in the book, resized to their appropriate
sizes. 

[kb-logos-gcs]: https://console.cloud.google.com/storage/browser/kubebuilder-logos 

[kb-logos-gcs-direct]: https://storage.googleapis.com/kubebuilder-logos
