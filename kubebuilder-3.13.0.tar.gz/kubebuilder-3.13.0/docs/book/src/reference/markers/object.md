# Object/DeepCopy

These markers control when `DeepCopy` and `runtime.Object` implementation
methods are generated.

{{#markerdocs object}}
