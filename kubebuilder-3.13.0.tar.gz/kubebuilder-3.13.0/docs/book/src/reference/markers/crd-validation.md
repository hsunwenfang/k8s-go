# CRD Validation

These markers modify how the CRD validation schema is produced for the
types and fields they modify.  Each corresponds roughly to an OpenAPI/JSON
schema option.

See [Generating CRDs](/reference/generating-crd.md) for examples.

{{#markerdocs CRD validation}}
