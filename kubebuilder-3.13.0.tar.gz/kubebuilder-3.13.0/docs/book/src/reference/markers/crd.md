# CRD Generation

These markers describe how to construct a custom resource definition from
a series of Go types and packages.  Generation of the actual validation
schema is described by the [validation markers](./crd-validation.md).

See [Generating CRDs](../generating-crd.md) for examples.

{{#markerdocs CRD}}
