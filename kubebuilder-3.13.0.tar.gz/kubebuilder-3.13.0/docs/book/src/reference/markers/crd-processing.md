# CRD Processing

These markers help control how the Kubernetes API server processes API
requests involving your custom resources.

See [Generating CRDs](/reference/generating-crd.md) for examples.

{{#markerdocs CRD processing}}
