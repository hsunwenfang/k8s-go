# TODO

If you're seeing this page, it's probably because something's not done in
the book yet, or you stumbled upon an old link.  Go [see if anyone else
has found
this](https://github.com/kubernetes-sigs/kubebuilder/issues?q=is%3Aopen+is%3Aissue+label%3Akind%2Fdocumentation)
or [bug the
maintainers](https://github.com/kubernetes-sigs/kubebuilder/issues/new?assignees=&labels=kind%2Fdocumentation).
