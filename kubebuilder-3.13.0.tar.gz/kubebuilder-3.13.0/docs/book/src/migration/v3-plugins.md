# V3 - Plugins Layout Migration Guides

Following the migration guides from the plugins versions. Note that the plugins ecosystem 
was introduced with Kubebuilder v3.0.0 release where the go/v3 version is the default layout
since `28 Apr 2021`.

Therefore, you can check here how to migrate the projects built from Kubebuilder 3.x with 
the plugin go/v3 to the latest.



