# Migrations

Migrating between project structures in Kubebuilder generally involves
a bit of manual work.

This section details what's required to migrate, between different
versions of Kubebuilder scaffolding, as well as to more complex project
layout structures.
