# Architecture Concept Diagram

The following diagram will help you get a better idea over the Kubebuilder concepts and architecture.  

<!-- include these inline so we can style an match variables -->
{{#include ./kb_concept_diagram.svg}}
